{
    onTryHit(damage, target, source, move) {
      target.addVolatile("charge");
    },
    flags: {},
    name: "Searing Voltage",
    rating: 3,
    num: 2180
}
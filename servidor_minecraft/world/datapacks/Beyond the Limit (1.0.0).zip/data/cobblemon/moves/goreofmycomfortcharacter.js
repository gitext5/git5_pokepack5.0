{
    num: -6666,
    accuracy: true,
    basePower: 140,
    category: "Physical",
    isNonstandard: "Past",
    name: "Gore of My Comfort Character",
    pp: 1,
    priority: 0,
    flags: {},
    ignoreAbility: true,
    isZ: "gorochiumz",
    recoil: [33, 100],
    secondary: {
      chance: 100,
      self: {
        boosts: {
          atk: 3
        }
      }
    },
    target: "normal",
    type: "Electric",
    contestType: "Cool"
  }
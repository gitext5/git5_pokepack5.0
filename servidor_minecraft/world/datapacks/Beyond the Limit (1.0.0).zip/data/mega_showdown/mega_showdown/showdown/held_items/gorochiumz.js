{
	name: "Gorochium Z",
	spritenum: -666,
	onTakeItem: false,
	zMove: "Gore of My Comfort Character",
	zMoveFrom: "Volt Tackle",
	itemUser: ["Gorochu"],
	num: -6690,
	gen: 7,
	isNonstandard: "Past"
}